const Heading = ({ children }) => (
  <h1 className="card-wrapper-description">{children}</h1>
);

export default Heading;
