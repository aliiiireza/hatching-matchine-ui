import styled, { css } from "styled-components";

const responsive = (styles) => {
  const sizes = {
    sm: "640px",
    md: "768px",
    lg: "1024px",
    xl: "1170px",
  };

  const screen = {
    sm: `screen and (max-width: ${sizes.md})`,
    md: `screen and (min-width: ${sizes.md}) and (max-width: ${sizes.xl})`,
    lg: `screen and (min-width: ${sizes.lg}) and (max-width: ${sizes.xl})`,
    xl: `screen and (min-width: ${sizes.xl})`,
    xlMax: `screen and (max-width:${sizes.xl})`,
  };

  let output = "";
  Object.entries(styles).forEach(([key, value]) => {
    output += `media only`;
  });
};
const Container = styled.div`
  padding: 15px;
  height: calc(100vh - 250px);
  border-radius: 40px;
  background-image: linear-gradient(
    154.62deg,
    rgba(255, 253, 253, 0.7) 3.67%,
    rgba(255, 250, 250, 0.1) 98.21%
  );
  box-shadow: 0px 4px 26px -1px #623ce775;
  backdrop-filter: blur(25px);
  border-radius: 30px;
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
  text-align: center;
  justify-content: space-between;
`;

const Header = styled.div`
  margin-bottom: 15px;
`;
const Footer = styled.div`
  margin-top: 15px;
`;
const Grid = styled.div`
  text-align: center;
  background-color: #623ce775;
  border-radius: 25px;
  height: 100%;
  box-shadow: 0px 0px 20px 0px #26185c75 inset;
  padding: 10px;
  overflow-x: hidden;
  overflow-y: auto;
`;
const GridItem = styled.div`
  margin: 10px;
  height: 500px;
  float: left;
  background-color: #ffffff42;
`;

const Title = styled.h1`
  color: #fff;
  text-align: left;
  font-weight: medium;
  font-size: 1.1rem;
  letter-spacing: 1px;
  margin: 0;
  text-align: center;
`;

const buttonVariants = {
  primary: css`
    background: radial-gradient(
          106.52% 100% at 86.81% 100%,
          rgba(0, 0, 0, 0.1) 0%,
          rgba(0, 0, 0, 0) 86.18%
        )
        /* warning: gradient uses a rotation that is not supported by CSS and may not behave as expected */,
      radial-gradient(
          55.45% 54.3% at 25.93% 25.27%,
          rgba(255, 255, 255, 0.679) 0%,
          rgba(255, 255, 255, 0) 69.79%,
          rgba(255, 255, 255, 0) 100%
        )
        /* warning: gradient uses a rotation that is not supported by CSS and may not behave as expected */,
      #00da9a;
  `,
  warning: css`
    background: radial-gradient(
          106.52% 100% at 86.81% 100%,
          rgba(0, 0, 0, 0.1) 0%,
          rgba(0, 0, 0, 0) 86.18%
        )
        /* warning: gradient uses a rotation that is not supported by CSS and may not behave as expected */,
      radial-gradient(
          55.45% 54.3% at 25.93% 25.27%,
          rgba(255, 255, 255, 0.679) 0%,
          rgba(255, 255, 255, 0) 69.79%,
          rgba(255, 255, 255, 0) 100%
        )
        /* warning: gradient uses a rotation that is not supported by CSS and may not behave as expected */,
      #fec60d;
  `,
  danger: css`
    background: radial-gradient(
        106.52% 100% at 86.81% 100%,
        rgba(0, 0, 0, 0.1) 0%,
        rgba(0, 0, 0, 0) 86.18%
      ),
      radial-gradient(
        55.45% 54.3% at 25.93% 25.27%,
        rgba(255, 255, 255, 0.679) 0%,
        rgba(255, 255, 255, 0) 69.79%,
        rgba(255, 255, 255, 0) 100%
      ),
      #ff4b0e;
  `,
};

const Button = styled.button`
  font-weight: 100;
  text-transform: uppercase;
  display: flex;
  border: none;
  font-size: var(--v-header-button-font-size);
  text-shadow: 1px 2px 2px rgb(0 0 0 / 50%);
  box-shadow: 1px 2px 10px rgb(0 0 0 / 50%);
  border-radius: 109px;
  color: white;
  height: var(--v-header-button-height);
  padding: 0 1.4rem;
  line-height: var(--v-header-button-height);
  transition: background 0.15s ease-in;
  box-shadow: 1px 2px 10px rgba(0, 0, 0, 0.5);
  background: radial-gradient(
        106.52% 100% at 86.81% 100%,
        rgba(0, 0, 0, 0.1) 0%,
        rgba(0, 0, 0, 0) 86.18%
      )
      /* warning: gradient uses a rotation that is not supported by CSS and may not behave as expected */,
    radial-gradient(
        55.45% 54.3% at 25.93% 25.27%,
        rgba(255, 255, 255, 0.679) 0%,
        rgba(255, 255, 255, 0) 69.79%,
        rgba(255, 255, 255, 0) 100%
      )
      /* warning: gradient uses a rotation that is not supported by CSS and may not behave as expected */,
    #00da9a;
  ${(props) => buttonVariants[props.type]}
`;

// interface CardsProps {
//   onClick?: () => any;
//   type?: "primary" | "success";
//   children?: JSX.Element | string;
//   loading?: boolean;
// }

const Cards = ({}) => {
  return (
    <>
      <Container>
        <Header>
          <Title>SELECT AN EGG TO HATCH</Title>
        </Header>
        <Grid>
          <GridItem />
          <GridItem />
          <GridItem />
          <GridItem />
          <GridItem />
          <GridItem />
          <GridItem />
        </Grid>
        <Footer>
          <Button type="warning">HATCH</Button>
        </Footer>
      </Container>
      <Container>
        <Header>
          <Title>SELECT AN EGG TO HATCH</Title>
        </Header>
        <Grid>
          <GridItem />
          <GridItem />
          <GridItem />
          <GridItem />
          <GridItem />
          <GridItem />
          <GridItem />
        </Grid>
      </Container>
    </>
  );
};
export default Cards;
